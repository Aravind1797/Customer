package com.example.demo.exception;

public class CustomerNotActive extends RuntimeException{
    public CustomerNotActive(String message) {
        super(message);
    }
}
