package com.example.demo.services;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;



    @Document(collection="Users")
    @Data
    @AllArgsConstructor
    @NoArgsConstructor

    public class Users {

        private  String username;
        String password;
        String role;
        private String email;


    }
