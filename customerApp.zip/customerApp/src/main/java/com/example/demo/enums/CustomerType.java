package com.example.demo.enums;

public enum CustomerType {
    INDIVIDUAL,
    JOINT,
}
