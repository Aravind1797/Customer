package com.example.demo.services;


import java.util.ArrayList;
import java.util.List;

public class UserServices {

    public List<User>sgetall();
            public void userserviceslist();
    {
        List<Users>  userlist = new ArrayList<>();
        userlist.add(name:"",password:"",email:"",role:"Admin")
                userlist.add(name:"",password:"",email:"",role:"Read");

    }

}
