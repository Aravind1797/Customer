package com.example.demo.model;

import com.example.demo.enums.CustomerType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.http.HttpStatus;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Collection;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "Customer")

public class Customer {

    @Id
    private int id;
    @NotNull(message = "First name cannot be left blank")
    @Size(min = 3 ,message = "atleast 3 character need to be present")
    private String firstname;
    @Size(max = 10,message="exits maximum size")
    private String lastname;
    private String City;
    private CustomerType customerType;


    public Customer(Customer customer, HttpStatus ok) {


    }
}
