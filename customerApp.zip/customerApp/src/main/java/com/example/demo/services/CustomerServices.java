package com.example.demo.services;

import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServices
{
   @Autowired
    CustomerRepo customerRepo;


   public List<Customer> getCustomerdetails()
   {
   return (List<Customer>) customerRepo.findAll();
   }

   public void addCustomer( Customer customer)
              {
                 customerRepo.save(customer);

   }

}
