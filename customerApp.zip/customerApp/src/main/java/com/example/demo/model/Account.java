package com.example.demo.model;

import lombok.Data;



@Data

public class Account {


    private int  accNumber;
     private String accType;
}
