package com.example.demo.enums;

public enum AccountType {
    CURRENT,
    CASH,
    INSTANT,
    FIXED_TERM_DEPOSIT
}
