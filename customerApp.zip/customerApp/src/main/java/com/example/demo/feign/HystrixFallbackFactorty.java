package com.example.demo.feign;


import org.springframework.stereotype.Component;

@Component
public class HystrixFallbackFactorty {



//    public AccountFeign create(Throwable cause) {
//        return (id) -> {
//            System.out.println("fallback; reason was: " + cause.getMessage());
//            return null;
//        };

    }
