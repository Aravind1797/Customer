package com.example.demo.feign;

public class CustomerRetryClientConfig {
}
