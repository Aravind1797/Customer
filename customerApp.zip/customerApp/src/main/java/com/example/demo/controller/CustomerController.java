package com.example.demo.controller;

import com.example.demo.model.Customer;
import com.example.demo.services.CustomerServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/DashBoard")
public class CustomerController {

    @Autowired
    CustomerServices customerServices;

    @GetMapping("/CustomerDetails")
    public List<Customer> getCustomerdetails()
    {

        return  customerServices.getCustomerdetails();
    }

    @PostMapping("/AddingCustomer")
    public void addCustomer(@RequestBody Customer customer)
    {
        customerServices.addCustomer(customer);

    }

}
