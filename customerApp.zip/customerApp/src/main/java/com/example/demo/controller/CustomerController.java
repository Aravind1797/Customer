package com.example.demo.controller;


import com.example.demo.model.Customer;
import com.example.demo.services.CustomerServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;


import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/DashBoard")
public class CustomerController {

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    CustomerServices customerServices;

    @GetMapping("/CustomerDetails")
    public List<Customer> getCustomerdetails()
    {

        return  customerServices.getCustomerdetails();
    }

    @PostMapping("/AddingCustomer")
    public void addCustomer(@RequestBody Customer customer) {
        customerServices.addCustomer(customer);

       // getAccount(customer);

//        restTemplate.postForObject(createPersonUrl, request, String.class);
//        {
    }
    @GetMapping("/getAccounts/{id}")
    public String getAccount(){
        //return restTemplate.exchange("http://greet-client/two/Customer",String.class);
        return restTemplate.exchange("http://Account/EntryPoint/AccDetails", HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
        }).getBody();

    }
    }




