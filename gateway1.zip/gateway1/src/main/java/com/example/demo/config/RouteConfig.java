package com.example.demo.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

public class RouteConfig {

    @Bean
    public RouteLocator gatewayRoutes(RouteLocatorBuilder routeLocatorBuilder)
    {
        return routeLocatorBuilder.routes()
                .route("oneModule", rt -> rt.path("/one/**")
                        .uri("http://localhost:8089/"))
                .route("twoModule", rt -> rt.path("/two/**")
                        .uri("http://localhost:8086/"))
                .build();

    }
}